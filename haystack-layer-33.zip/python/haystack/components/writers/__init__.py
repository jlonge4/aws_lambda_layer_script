# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

from haystack.components.writers.document_writer import DocumentWriter

__all__ = ["DocumentWriter"]
